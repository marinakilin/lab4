package com.example.lab42;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements OnListClick {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public void onListClicked(String url) {
        SecondFragment fragment = (SecondFragment) getSupportFragmentManager().findFragmentById(R.id.secondFragment);
        fragment.load(url);
    }
}
