package com.example.lab42;

public interface OnListClick {
    void onListClicked(String url);
}
